babel src --watch --out-dir build
