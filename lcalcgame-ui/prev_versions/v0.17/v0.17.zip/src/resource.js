
// USAGE EXAMPLE: Resource.audio('pop');
var Resource = (() => {

    const __RESOURCE_PATH = 'resources/';
    const __AUDIO_PATH = __RESOURCE_PATH + 'audio/';
    const __GRAPHICS_PATH = __RESOURCE_PATH + 'graphics/';
    var audioRsc = {};
    var imageRsc = {};
    var animPresets = {};
    var levels = [];
    var loadAudio = (alias, filename) => {
        var audio = new Audio(__AUDIO_PATH + filename);
        audioRsc[alias] = audio;
    };
    var loadImage = (alias, filename) => {
        var img = new Image();
        img.src = __GRAPHICS_PATH + filename;
        img.alt = alias;
        imageRsc[alias] = img;
    };
    var loadImageSequence = (alias, filename, range) => {
        let a = filename.split('.');
        let name = a[0];
        let ext = a[1];
        for (let i = range[0]; i <= range[1]; i++)
            loadImage(alias + i, name + i + '.' + ext);
    };
    var loadAnimation = (imageSeqAlias, range, duration) => {
        animPresets[imageSeqAlias] = Animation.forImageSequence(imageSeqAlias, range, duration);
    };

    // Add resources here:
    loadAudio('pop', 'pop.wav');
    loadAudio('poof', 'poof.wav');
    loadAudio('bag-spill', 'spill.wav');
    loadAudio('bag-addItem', 'putaway.wav');
    loadAudio('victory', '325805__wagna__collect.wav');
    loadImage('bag-background', 'bg-stars.png');
    loadImage('lambda-hole', 'lambda-hole.png');
    loadImage('lambda-hole-closed', 'lambda-hole-closed.png');
    loadImage('lambda-pipe', 'lambda-pipe-closed.png');
    loadImage('lambda-pipe-open', 'lambda-pipe-open.png');
    loadImage('lambda-pipe-opening0', 'lambda-pipe-opening0.png');
    loadImage('lambda-pipe-opening1', 'lambda-pipe-opening1.png');

    // Loads poof0.png, poof1.png, ..., poof4.png (as poof0, poof1, ..., poof4, respectively).
    loadImageSequence('poof', 'poof.png', [0, 4]);

    // Load preset animations from image sequences.
    loadAnimation('poof', [0, 4], 120); // Cloud 'poof' animation for destructor piece.

    // Add levels here: (for now)
    // * The '/' character makes the following expression ignore mouse events (can't be drag n dropped). *

    // DEBUG LEVEL(s)
    //levels.push(['(λx /(== #_x star)) (diamond)', 'star']);
    //levels.push(['(λx #x #_x #x) (== _ 1) (bag) (count) (2) (5) (4) (3) (6) (if _ circle triangle)', 'star']);

    // VERSION 0.14 LEVELS
    // Introduces concept: Identity.
    levels.push(['(λx #x) (star)', 'star']);
    levels.push(['(λx #x) (λy #y) (star) (star)', '(star) (star)']);
    levels.push(['(λx #x) (λy #y) (λz #z) (star)', 'star']);

    // Introduces concept: Deletion.
    levels.push(['(λy) (diamond) (star)', 'star']);

    // Furthers Deletion: Can delete multiple items.
    levels.push(['(λy) (λz) (diamond) (diamond) (star)', 'star']);
    //levels.push(['(λy) (λz) (λw) (λx) (diamond) (diamond) (diamond) (star) (star)', 'diamond']);

    // Mixes Identity and Deletion.
    // > also introduces: Objective other than star.
    levels.push(['(λx #x) (λy) (diamond) (star)', 'diamond']);

    // Furthers mixing Identity and Deletion.
    //levels.push(['(λx #x) (λy) (λz) (diamond) (diamond) (star)', 'star']);
    //levels.push(['(λx #x) (λy #y) (λz) (diamond) (star)', 'star']);
    levels.push(['(λx #x) (λy #y) (λz) (λw) (diamond) (diamond) (star)', 'diamond']);

    // Introduces concept: Replication.
    levels.push(['(λx #x #x) (star)', '(star) (star)']);
    levels.push(['(λx #x #x) (λy) (star) (diamond)', '(diamond) (diamond)']);

    // Introduces concept: Functions are first-class!
    // > also: Replication of expressions.
    levels.push(['(λx #x #x) (λx #x) (star)', 'star']); // Only solution is to double the identity.
    levels.push(['(λx #x #x #x) (λx #x) (diamond)', 'diamond']); // Hammers this home a bit more.
    // > furthers deletion: Can delete expressions.
    levels.push(['(λx #x #x) (λy) (star)', 'star']);
    levels.push(['(λx #x #x) (λy) (star) (diamond) (diamond)', 'diamond']);
    levels.push(['(λx #x #x) (λy #y) (λz) (star) (diamond)', '(star) (diamond)']);

    // Introduces concept: You can drop holes into other holes.
    levels.push(['(λy) (λz) (star)', 'star']);
    // > harder puzzle requiring this concept.
    levels.push(['(λx #x #x #x) (λy) (star) (diamond)', 'star']);

    // Some harder puzzles using prior concepts.
    levels.push(['(λx #x #x) (λy #y) (λz) (star) (diamond) (diamond)', '(diamond) (diamond)']);
    // levels.push(['(λx (λy #y)) (star) (diamond)', 'star']);
    //levels.push(['(λx #x #x #x) (λy (λz #z)) (diamond) (diamond)', '(diamond) (diamond)']);
    levels.push(['(λx #x #x #x) (λy #y #y) (λz #z) (λw) (star) (diamond)', '(star) (star) (star)']);
    //levels.push(['(λx #x #x #x) (λy #y #y) (λz #z) (λw) (star) (diamond)', 'star']); // T9* redundant

    // Introduces concept: Reduction; Boolean comparison.
    levels.push(['(== /star /star)', 'true']);

    // Introduces concept: Holes.
    levels.push(['(== _ /star) (star)', 'true']);
    // > mixes with deletion.
    levels.push(['(== /diamond _) (diamond) (star) (λx)', 'true']);
    // > mixes with replication.
    levels.push(['(star) (== /star _) (λx #x #x)', '(true) (true)']);
    levels.push(['(== /star /diamond)', 'false']);
    levels.push(['(== _ /diamond) (star) (diamond) (λx)', 'false']);
    levels.push(['(== _ _) (star) (diamond)', 'false']);
    levels.push(['(== /star _) (λx #x #x) (diamond) (diamond)', '(false) (false)']);
    levels.push(['(== _ _) (λx #x #x) (λy #y #y) (star) (diamond)', '(true) (false)']);

    // Introduces concept: Functions as goals.
    //levels.push(['(λx #x) (λy) (star)', '(λx #x)']);

    // Introduces concept: Boundless expansion.
    levels.push(['(λx #x #x #x) (λy #y #y) (star) (diamond)', '(diamond) (diamond) (diamond) (star) (star) (star) (star) (star)']);

    // CHAPTER 2: MOVING LAMBDA VARIABLES
    levels.push(['(λx /star) (diamond)', 'star']);
    levels.push(['(λx diamond) (star)', 'star']);
    levels.push(['(λx /diamond) (λx /star)', 'diamond']);
    levels.push(['(λx /diamond) (λx /star) (λx /diamond) (diamond) (λx #x)', 'star']);
    levels.push(['(λx /star) (diamond) (diamond) (λx #x #x)', '(star) (star)']);
    levels.push(['(λx /diamond) (star) (star) (λx #x #x #x) (λx #x)', '(diamond) (star)']);
    levels.push(['(λx star) (diamond) (diamond) (λx #x #x)', '(rect) (rect) (rect)']);
    levels.push(['(λx _) (star) (#_x)', 'star']);
    levels.push(['(λx 5) (star) (λy) (#_x)', 'star']);
    levels.push(['(λx _) (star) (#_x) (λy)', 'star']);

    // Make the replicator.
    levels.push(['(λx 5 star) (#_x) (#_x) (λy)', '(star) (star)']);

    // // many solutions //
    levels.push(['(λx #x #x #_x) (λy diamond) (star) (λy)', 'star']);

    // HARD: make the replicators + boundless explansion callback
    //levels.push(['(λx #_x #_x diamond) (λy star #y) (#_x) (#_x)', '(diamond) (diamond) (diamond) (star) (star) (star) (star) (star)']);

    levels.push(['(λx star) (== #x #x)', 'true']);
    levels.push(['(λx 5) (star) (== #x _)', 'false']);

    levels.push(['(λx #x #x) (λx star) (== #x /diamond) (diamond)', '(true) (false)']);

    // Replication of partial lambda functions:
    // AAAAAAAHHHHHHHHHHH!!!!
    levels.push(['(λx #x #x) (λx star) (== #x /5)', 'false']);

    /*levels.push(['(λx #x) (triangle)', 'triangle']);
    levels.push(['(λx #x) (λy #y)', '(λx #x)']);
    levels.push(['(if false /triangle /rect)', 'rect']);
    levels.push(['(if _ circle triangle) (!= /triangle _) (star)', 'star']);
    levels.push(['(if _ /star /circle) (== /triangle _) (rect) (λx λy #x) (triangle)', 'star']);*/

    //levels.push(Level.make('(if _ /rect false) (if _ /star /circle) (== /triangle _) (rect) (triangle)', 'star'));

    return { // TODO: Add more resource types.
        audio:audioRsc,
        image:imageRsc,
        getImage:(name) => imageRsc[name],
        getAudio:(name) => audioRsc[name],
        getAnimation:(name) => animPresets[name].clone(),
        play:(alias, volume) => {
            if(volume) audioRsc[alias].volume = volume;
            else audioRsc[alias].volume = 1.0;
            audioRsc[alias].play();
        },
        buildLevel:(idx, canvas) => Level.make(levels[idx][0], levels[idx][1]).build(canvas),
        level:levels
    };
})();
