/**
 * Lambda calculus versions of Expression objects.
 * The LambdaHoleExpr performs substitution on LambdaVar subexpressions in its parent expression context.
 * -----------------------------------------------
 * */
class LambdaHoleExpr extends MissingExpression {
    static openImage() { return 'lambda-hole'; }
    static closedImage() { return 'lambda-hole-closed'; }
    constructor(varname) {
        super(null);
        this._name = varname;
        this.color = this.colorForVarName();
        this.image = LambdaHoleExpr.openImage();
        this.isOpen = true;
    }
    get name() { return this._name; }
    set name(n) { this._name = n; }

    static colorForVarName(v) {
        return {

            'x':'orange',
            'y':'blue',
            'z':'green',
            'w':'red'

        }[v];
    }
    colorForVarName() { return LambdaHoleExpr.colorForVarName(this.name); }

    // Draw special circle representing a hole.
    drawInternal(pos, boundingSize) {
        var ctx = this.ctx;
        var rad = boundingSize.w / 2.0;
        setStrokeStyle(ctx, this.stroke);
        ctx.fillStyle = this.color;
        ctx.beginPath();
        ctx.arc(pos.x+rad,pos.y+rad,rad,0,2*Math.PI);
        this.ctx.drawImage(Resource.getImage(this.image), pos.x, pos.y, boundingSize.w, boundingSize.h);
        if(this.stroke) ctx.stroke();
    }

    // Accessibility
    open() {
        this.image = LambdaHoleExpr.openImage();
        this.isOpen = true;
    }
    close() {
        this.image = LambdaHoleExpr.closedImage();
        this.isOpen = false;
    }
    hits(pos, options=undefined) {
        if (this.isOpen)
            return super.hits(pos, options);
        else
            return null;
    }

    // Events
    onmousedrag(pos) {
        if (this.parent) {
            pos = addPos(pos, fromTo(this.absolutePos, this.parent.absolutePos));
            this.parent.onmousedrag(pos);
        }
    }
    ondropenter(node, pos) {
        if (node instanceof LambdaHoleExpr) node = node.parent;
        super.ondropenter(node, pos);
        node.opacity = 0.2;
        if (this.parent) {
            var subvarexprs = Stage.getNodesWithClass(LambdaVarExpr, [], true, [this.parent]);
            subvarexprs.forEach((e) => {
                let preview_node = node.clone();
                preview_node.opacity = 1.0;
                preview_node.bindSubexpressions();
                e.open(preview_node);
            });
            this.opened_subexprs = subvarexprs;
            this.close_opened_subexprs = () => {
                if (!this.opened_subexprs) return;
                this.opened_subexprs.forEach((e) => {
                    e.close();
                });
                this.opened_subexprs = null;
            };
        }
    }
    ondropexit(node, pos) {
        if (node instanceof LambdaHoleExpr) node = node.parent;
        super.ondropexit(node, pos);
        node.opacity = 1.0;
        this.close_opened_subexprs();
    }
    ondropped(node, pos) {
        if (node instanceof LambdaHoleExpr) node = node.parent;
        if (node.dragging) { // Make sure node is being dragged by the user.

            // Cleanup
            node.opacity = 1.0;
            this.close_opened_subexprs();

            // User dropped an expression into the lambda hole.
            Resource.play('pop');

            // Clone the dropped expression.
            var dropped_expr = node.clone();

            // Save the current state of the board.
            var stage = node.stage;
            stage.saveState();

            Logger.log('state-save', stage.toString());

            // Remove the original expression from its stage.
            stage.remove(node);

            // If this hole is part of a larger expression tree (it should be!),
            // attempt recursive substitution on any found LambdaVarExpressions.
            if (this.parent) {
                var parent = this.parent;
                let orig_exp_str = parent.toString();
                let dropped_exp_str = node.toString();

                var subvarexprs = this.stage.getNodesWithClass(LambdaVarExpr, [], true, [parent]);
                subvarexprs.forEach((expr) => {
                    if (expr.name === this.name) {
                        var c = dropped_expr.clone();
                        c.bindSubexpressions();
                        c.stage = null;
                        expr.parent.swap(expr, c); // Swap the expression for a clone of the dropped node.
                    }
                });

                // Now remove this hole from its parent expression.
                parent.removeArg(this);

                // GAME DESIGN CHOICE: Automatically break apart parenthesized values.
                // * If we don't do this, the player can stick everything into one expression and destroy that expression
                // * to destroy as many expressions as they like with a single destruction piece. And that kind of breaks gameplay.
                parent.performReduction();

                // Log the reduction.
                Logger.log('reduction-lambda', { 'before':orig_exp_str, 'applied':dropped_exp_str, 'after':parent.toString() });
                Logger.log('state-save', stage.toString());

                if (parent.children.length === 0) {

                    // This hole expression is a destructor token.
                    // (a) Play nifty 'POOF' animation.
                    if (parent.stage) {
                        let sz = parent.size;
                        let pos = parent.pos;
                        let scale = 1.4;
                        let img = new ImageRect(pos.x - sz.w*(scale-1.0)/2.0,
                                                pos.y - sz.h*(scale-1.0)/2.0,
                                                sz.w*1.4, sz.h*1.4, 'poof0');
                        parent.stage.add(img);
                        let anim = Resource.getAnimation('poof');
                        Animate.play(anim, img, () => {
                            let stg = img.stage;
                            stg.remove(img); // remove self from stage on animation end.
                            stg.draw();
                        });

                        Resource.play('poof', 0.4);
                    }
                    // (b) Remove expression from the parent stage.
                    (parent.parent || parent.stage).remove(parent);

                } else
                    stage.dumpState();

            } else {
                console.warn('ERROR: Cannot perform lambda-substitution: Hole has no parent.');

                // Hole is singular; acts as abyss. Remove it after one drop.
                this.stage.remove(this);
            }
        }
    }

    toString() { return 'λ' + this.name; }
}

class LambdaVarExpr extends ImageExpr {
    constructor(varname) {
        super(0, 0, 54*1.2, 70*1.2, 'lambda-pipe');
        this.graphicNode.offset = { x:0, y:-8 };
        this.name = varname;
        this.ignoreEvents = true;

        // Graphic animation.
        this.stateGraph.enter('closed');
    }

    get stateGraph() {
        if (!this._stateGraph) {
            var g = new StateGraph();
            g.addState('closed', () => {
                this.image = 'lambda-pipe'; });
                if(this.stage) this.stage.draw();
            g.addState('opening', () => {
                var anim = new Animation();
                anim.addFrame('lambda-pipe-opening0', 50);
                anim.addFrame('lambda-pipe-opening1', 50);
                anim.addFrame('lambda-pipe-open',     50);
                Animate.play(anim, this, () => {
                    g.enter('open');
                });
            });
            g.addState('open', () => {
                this.image = 'lambda-pipe-open'; });
                if(this.stage) this.stage.draw();
            g.addState('closing', () => {
                var anim = new Animation();
                anim.addFrame('lambda-pipe-opening1', 50);
                anim.addFrame('lambda-pipe-opening0', 50);
                anim.addFrame('lambda-pipe',          50);
                Animate.play(anim, this, () => {
                    g.enter('closed');
                });
            });
            this._stateGraph = g;
        }
        return this._stateGraph;
    }
    clone() {
        var c = super.clone();
        c._stateGraph = null;
        c.stateGraph.enter('closed');
        return c;
    }

    open(preview_expr=null) {
        if (this.stateGraph.currentState !== 'open') {
            this.stateGraph.enter('opening');

            if(preview_expr) {
                setTimeout(() => {
                    if (this.stateGraph.currentState === 'opening') {
                        let scale = this.graphicNode.size.w / preview_expr.size.w * 0.8;
                        preview_expr.pos = { x:this.children[0].size.w/2.0, y:-10 };
                        preview_expr.scale = { x:scale, y:scale };
                        preview_expr.anchor = { x:0.5, y:0 };
                        preview_expr.stroke = null;
                        this.graphicNode.addChild(preview_expr);
                        this.stage.draw();
                    }
                }, 150);

            }
        }
    }
    close() {
        if (this.stateGraph.currentState !== 'closed') {
            this.stateGraph.enter('closing');
            this.graphicNode.children = [];
        }
    }

    //onmousedrag() {}
    drawInternal(pos, boundingSize) {
        super.drawInternal(pos, boundingSize);
        if (this.ctx && !this.parent) {
            this.scale = { x:0.8, y:0.8 };
            drawCircle(this.ctx, pos.x, pos.y-8+this.shadowOffset, boundingSize.w / 2.0, 'black', this.graphicNode.stroke);
            drawCircle(this.ctx, pos.x, pos.y-8, boundingSize.w / 2.0, 'lightgray', this.graphicNode.stroke);
        }
    }

    value() { return undefined; }
    toString() { return '#' + (this.ignoreEvents ? '' : '_') + this.name; }
}

class LambdaExpr extends Expression {
    constructor(exprs) {
        super(exprs);

        /*let txt = new TextExpr('→');
        txt.color = 'gray'
        this.addArg(txt);*/
    }
    addChild(c) {
        super.addChild(c);

        // Color all subvarexpr's of child consistently with their names.
        if (this.takesArgument) {
            this.updateHole();

            var hole = this.holes[0];
            var lvars = Stage.getNodesWithClass(LambdaVarExpr, [], true, [this]);
            lvars.forEach((v) => {
                if (v.name === hole.name) {
                    v.color = hole.colorForVarName();
                }
            });
        }
    }
    get isParentheses() { return this.holes.length > 0 && !(this.takesArgument); }
    get takesArgument() { return this.holes.length > 0 && this.holes[0] instanceof LambdaHoleExpr; }
    get fullyDefined() {
        // If one arg is MissingExpression, this will be false.
        if (this.holes.length < 2) return true;
        return this.holes.slice(1).reduce(((prev,arg) => (prev && !(arg instanceof MissingExpression))), true);
    }
    updateHole() {
        // Determine whether this LambdaExpr has any MissingExpressions:
        let missing = !this.fullyDefined;
        if (missing) this.holes[0].close();
        else         this.holes[0].open();
    }

    // Close lambda holes appropriately.
    swap(node, otherNode) {
        super.swap(node, otherNode);
        if (this.takesArgument) {
            if (otherNode instanceof MissingExpression) { // if expression was removed...
                this.holes[0].close(); // close the hole, undoubtedly
            } else if (node instanceof MissingExpression) { // if expression was placed...
                this.updateHole();
            }
        }
    }

    onmouseclick(pos) {
        this.performReduction();
    }
    hitsChild(pos) {
        if (this.isParentheses) return null;
        return super.hitsChild(pos);
    }
    reduce() {
        // Remove 'parentheses':
        if (this.isParentheses) {
            return this.holes;
        } else return super.reduce();
    }
    performReduction() {

        var reduced_expr = this.reduce();
        if (reduced_expr && reduced_expr != this) { // Only swap if reduction returns something > null.

            this.stage.saveState();

            var parent;
            if (Array.isArray(reduced_expr)) {
                if (reduced_expr.length === 1) { reduced_expr = reduced_expr[0]; } // reduce to single argument
                else if (this.parent) return; // cannot reduce a parenthetical expression with > 1 subexpression.
                else {
                    parent = this.stage;
                    reduced_expr.forEach((e) => {
                        if (this.locked) e.lock();
                        else             e.unlock();
                    });
                    parent.swap(this, reduced_expr); // swap 'this' (on the board) with an array of its reduced expressions
                    return;
                }
            }

            parent = this.parent ? this.parent : this.stage;
            if (this.locked) reduced_expr.lock(); // the new expression should inherit whatever this expression was capable of as input
            else             reduced_expr.unlock();
            parent.swap(this, reduced_expr);

            if (reduced_expr.parent) {
                var try_reduce = reduced_expr.parent.reduceCompletely();
                if (try_reduce != reduced_expr.parent && try_reduce !== null) {
                    Animate.blink(reduced_expr.parent, 400, [0,1,0]);
                }
            }
        }
    }

    toString() {
        if (this.holes.length === 1 && this.holes[0] instanceof LambdaHoleExpr)
            return '(' + super.toString() + ')';
        else
            return super.toString();
    }
}
