
/**
 *	Lambda Calc V3
 *  --------------
 * 	Foundation structures
 */

 const EMPTY_EXPR_WIDTH = 50;
 const DEFAULT_EXPR_HEIGHT = 50;
 const DEFAULT_CORNER_RAD = 20;
 var DEFAULT_RENDER_CTX = null;

/** A generic expression. Could be a lambda expression, could be an if statement, could be a for.
    In general, anything that takes in arguments and can reduce to some other value based on those arguments. */
class Expression extends RoundedRect {
    constructor(holes=[]) {
        super(0, 0, EMPTY_EXPR_WIDTH, DEFAULT_EXPR_HEIGHT, DEFAULT_CORNER_RAD);

        this.holes = holes;
        this.padding = 10;
        this._size = { w:EMPTY_EXPR_WIDTH, h:DEFAULT_EXPR_HEIGHT };

        if (this.holes) {
            var _this = this;
            this.holes.forEach((hole) => {
                _this.addChild(hole);
            });
        }
    }
    equals(otherNode) {
        if (otherNode instanceof Expression && this.holes.length === otherNode.holes.length) {
            if (this.holes.length === 0)
                return this.value === otherNode.value;
            else {
                var b = true;
                for(let i = 0; i < this.holes.length; i++)
                    b &= this.holes[i].value === otherNode[i].value;
                return b;
            }
        }
        return false;
    }
    clone(parent=null) {
        var c = super.clone(parent);
        var children = c.children;
        c.children = [];
        c.holes = [];
        c.stroke = null;
        children.forEach((child) => c.addArg(child));
        return c;
    }

    // Makes all inner expressions undraggable, 'binding' them permanently.
    bindSubexpressions() {
        this.holes.forEach((hole) => {
            if (hole instanceof Expression && !(hole instanceof MissingExpression)) {
                if (hole instanceof VarExpr)
                    hole.ignoreEvents = true;
                hole.bindSubexpressions();
            }
        });
    }

    addArg(arg) {
        this.holes.push(arg);
        this.addChild(arg);
    }
    removeArg(arg) {
        var idx = this.holes.indexOf(arg);
        if (idx > -1) {
            this.holes.splice(idx, 1); // remove 1 elem @ idx
            this.update();
            //this.stage.draw();
        } else console.error('@ removeArg: Could not find arg ', arg, ' in expression.');
    }
    swap(arg, anotherArg) {
        if (!arg || !anotherArg) return;
        var i = this.holes.indexOf(arg);
        if (i > -1) {
            anotherArg.pos = arg.pos;
            anotherArg.dragging = false;
            this.holes.splice(i, 1, anotherArg);
            anotherArg.parent = this;
            anotherArg.scale = { x:0.85, y:0.85 };
            anotherArg.onmouseleave();
            anotherArg.onmouseup();
            arg.parent = null;
            this.update();
        }
        else console.log('Cannot swap: Argument ', arg, ' not found in parent.');
    }

    get holeCount() {
        return this.holes ? this.holes.length : 0;
    }

    // Sizes to match its children.
    get size() {

        var width = 0;
        var padding = this.padding;
        var sizes = this.getHoleSizes();
        var scale_x = this.scale.x;

        if (sizes.length === 0) return { w:this._size.w, h:this._size.h };

        sizes.forEach((s) => {
            width += s.w + padding;
        });
        width += padding; // the end

        //if(this.color === 'red') width *= 0.8;
        return { w:width, h:DEFAULT_EXPR_HEIGHT };
    }

    getHoleSizes() {
        if (!this.holes || this.holes.length === 0) return [];
        var sizes = [];
        this.holes.forEach((expr) => {
            var size = expr ? expr.size : {w:EMPTY_EXPR_WIDTH, h:DEFAULT_EXPR_HEIGHT};
            size.w *= expr.scale.x;
            sizes.push(size);
        });
        return sizes;
    }

    update() {
        var padding = this.padding;
        var x = padding;
        var y = this.size.h / 2.0;
        var _this = this;
        this.children = [];
        this.holes.forEach((expr) => _this.addChild(expr));
        this.holes.forEach((expr) => { // Update hole expression positions.
            expr.anchor = { x:0, y:0.5 };
            expr.pos = { x:x, y:y };
            expr.scale = { x:0.85, y:0.85 };
            expr.update();
            x += expr.size.w * expr.scale.x + padding;
        });
        this.children = this.holes; // for rendering
    }

    // Apply arguments to expression
    apply(args) {
        // ... //
    }

    // Apply a single argument at specified arg index
    applyAtIndex(idx, arg) {
        // ... //
    }

    // Reduce this expression to another.
    // * Returns the newly built expression. Leaves this expression unchanged.
    reduce(options=undefined) {
        return this;
    }
    // * Swaps this expression for its reduction (if one exists) in the expression hierarchy.
    performReduction() {
        var reduced_expr = this.reduce();
        if (reduced_expr && reduced_expr != this) { // Only swap if reduction returns something > null.

            console.warn('performReduction with ', this, reduced_expr);

            this.stage.saveState();
            Logger.log('state-save', this.stage.toString());

            // Log the reduction.
            let reduced_expr_str;
            if (Array.isArray(reduced_expr))
                reduced_expr_str = reduced_expr.reduce((prev,curr) => (prev + curr.toString() + ' '), '').trim();
            else reduced_expr_str = reduced_expr.toString();
            Logger.log('reduction', { 'before':this.toString(), 'after':reduced_expr_str });

            var parent = this.parent ? this.parent : this.stage;
            reduced_expr.ignoreEvents = this.ignoreEvents; // the new expression should inherit whatever this expression was capable of as input
            parent.swap(this, reduced_expr);

            if (reduced_expr.parent) {
                var try_reduce = reduced_expr.parent.reduceCompletely();
                if (try_reduce != reduced_expr.parent && try_reduce !== null) {
                    Animate.blink(reduced_expr.parent, 400, [0,1,0]);
                }
            }
        }
    }
    reduceCompletely() { // Try to reduce this expression and its subexpressions as completely as possible.
        var e = this;
        var prev_holes = e.holes;
        //e.parent = this.parent;
        if (e.children.length === 0) return e.reduce();
        else {
            e.holes = e.holes.map((hole) => {
                if (hole instanceof Expression)
                    return hole.reduceCompletely();
                else
                    return hole;
            });
            console.warn('Reduced: ', e.holes);
            e.children = [];
            e.holes.forEach((hole) => e.addChild(hole));
            var red = e.reduce();
            e.holes = prev_holes;
            e.holes.forEach((hole) => e.addChild(hole));
            return red;
        }
    }

    detach() {
        if (this.parent) {
            var ghost_expr = new MissingExpression(this);
            var _this = this;
            var stage = this.parent.stage;
            this.parent.swap(this, ghost_expr);
            stage.add(this);
            stage.bringToFront(this);
            this.shell = ghost_expr;
        }
    }

    lock() {
        this.shadowOffset = 0;
        this.ignoreEvents = true;
        this.locked = true;
    }
    unlock() {
        this.shadowOffset = 2;
        this.ignoreEvents = false;
        this.locked = false;
    }

    hits(pos, options=undefined) {
        if (this.locked) return this.hitsChild(pos, options);
        else             return super.hits(pos, options);
    }

    onmousedrag(pos) {
        super.onmousedrag(pos);
        const rightX = pos.x + this.absoluteSize.w;
        if (rightX < GLOBAL_DEFAULT_SCREENSIZE.width) {
            this.pos = pos;
        } else this.pos = { x:GLOBAL_DEFAULT_SCREENSIZE.width - this.absoluteSize.w, y:pos.y };
        if (!this.dragging) {
            this.detach();
            this.stage.bringToFront(this);
            this.dragging = true;
        }
    }
    onmouseup(pos) {
        if (this.dragging && this.shell) {
            if(!this.parent) this.scale = { x:1, y:1 };
            this.shell = null;
            //this.shell.stage.remove(this);
            //this.shell.stage = null;
            //this.shell.parent.swap(this.shell, this); // put it back
            //this.shell = null;
        }
        this.dragging = false;
    }

    // The value (if any) this expression represents.
    value() { return undefined; }
    toString() {
        if (this.holes.length === 1) return this.holes[0].toString();
        let s = '(';
        for (let i = 0; i < this.holes.length; i++) {
            if (i > 0) s += ' ';
            s += this.holes[i].toString();
        }
        return s + ')';
    }
}

class MissingExpression extends Expression {
    constructor(expr_to_miss) {
        super([]);
        if (!expr_to_miss) expr_to_miss = new Expression();
        this.shadowOffset = -1; // inner
        this.color = '#555555';
        this._size = { w:expr_to_miss.size.w, h:expr_to_miss.size.h };
        this.ghost = expr_to_miss;
    }
    onmousedrag(pos) { } // disable drag
    ondropenter(node, pos) {
        this.onmouseenter(pos);
    }
    ondropexit(node, pos) {
        this.onmouseleave(pos);
    }
    ondropped(node, pos) {
        super.ondropped(node, pos);
        if (node.dragging) { // Reattach node.
            Resource.play('pop');
            node.stage.remove(node);
            this.parent.swap(this, node); // put it back

            // Blink red if total reduction is not possible with this config.
            /*var try_reduce = node.parent.reduceCompletely();
            if (try_reduce == node.parent || try_reduce === null) {
                Animate.blink(node.parent, 400, [1,0,0]);
            }*/

            // Blink blue if reduction is possible with this config.
            var try_reduce = node.parent.reduceCompletely();
            if (try_reduce != node.parent && try_reduce !== null) {
                Animate.blink(node.parent, 400, [0,1,0]);
            }
        }
    }

    toString() { return '_'; }
}

class TextExpr extends Expression {
    constructor(txt, font='Consolas', fontSize=35) {
        super();
        this.text = txt;
        this.font = font;
        this.fontSize = fontSize; // in pixels
        this.color = 'black';
    }
    get size() {
        var ctx = this.ctx || GLOBAL_DEFAULT_CTX;
        if (!ctx || !this.text || this.text.length === 0) {
            console.error('Cannot size text: No context.');
            return { w:4, h:this.fontSize };
        }
        ctx.font = this.contextFont;
        var measure = ctx.measureText(this.text);
        return { w:measure.width, h:DEFAULT_EXPR_HEIGHT };
    }
    get contextFont() {
        return this.fontSize + 'px ' + this.font;
    }
    drawInternal(pos, boundingSize) {
        var ctx = this.ctx;
        var abs_scale = this.absoluteScale;
        ctx.save();
        ctx.font = this.contextFont;
        ctx.scale(abs_scale.x, abs_scale.y);
        ctx.fillStyle = this.color;
        ctx.fillText(this.text, pos.x / abs_scale.x, pos.y / abs_scale.y + 2.2 * this.fontSize * this.anchor.y);
        ctx.restore();
    }
    hits(pos, options) { return false; } // disable mouse events
    value() { return this.text; }
}

class BooleanPrimitive extends Expression {
    constructor(name) {
        super();
        var text = new TextExpr(name);
        text.pos = { x:0, y:0 };
        text.anchor = { x:-0.1, y:1.5 }; // TODO: Fix this bug.
        this.addArg(text);
    }
}
class TrueExpr extends BooleanPrimitive {
    constructor() {
        super('true');
    }
    value() { return true; }
    toString() { return 'true'; }
}
class FalseExpr extends BooleanPrimitive {
    constructor() {
        super('false');
    }
    value() { return false; }
    toString() { return 'false'; }
}
class EmptyExpr extends Expression {
    value() { return null; }
}

// An if statement.
class IfStatement extends Expression {
    constructor(cond, branch) {
        var if_text = new TextExpr('if');
        if_text.color = 'black';
        super([if_text, cond, branch]);
        this.color = 'LightBlue';
    }

    get cond() { return this.holes[1]; }
    get branch() { return this.holes[2]; }
    get emptyExpr() { return new EmptyExpr(); }
    get constructorArgs() { return [this.cond.clone(), this.branch.clone()]; }

    onmouseclick(pos) {
        this.performReduction();
    }

    reduce() {
        if (!this.cond || !this.branch) return this; // irreducible
        var cond_val = this.cond.value();
        if (cond_val === true)          return this.branch; // return the inner branch
        else if (cond_val === false)    return this.emptyExpr; // disappear
        else                            return this; // something's not reducable...
    }

    value() {
        return undefined;
    }
    toString() {
        return '(if ' + this.cond.toString() + ' ' + this.branch.toString() + ')';
    }
}
class IfElseStatement extends IfStatement {
    constructor(cond, branch, elseBranch) {
        super(cond, branch);
        var txt = new TextExpr('else');
        txt.color = 'black';
        this.addArg(txt);
        this.addArg(elseBranch);
    }
    get elseBranch() { return this.holes[4]; }
    get constructorArgs() { return [this.cond.clone(), this.branch.clone(), this.elseBranch.clone()]; }

    reduce() {
        if (!this.cond || !this.branch || !this.elseBranch) return this; // irreducible
        var cond_val = this.cond.value();
        console.log(this.cond, cond_val);
        if (cond_val === true)          return this.branch; // return the inner branch
        else if (cond_val === false)    return this.elseBranch; // disappear
        else                            return this; // something's not reducable...
    }

    toString() {
        return '(if ' + this.cond.toString() + ' ' + this.branch.toString() + ' ' + this.elseBranch.toString() + ')';
    }
}

// A boolean compare function like ==, !=, >, >=, <=, <.
class CompareExpr extends Expression {
    static operatorMap() {
        return { '==':'is', '!=':'≠' };
    }
    static textForFuncName(fname) {
        var map = CompareExpr.operatorMap();
        if (fname in map) return map[fname];
        else              return fname;
    }
    constructor(b1, b2, compareFuncName='==') {
        var compare_text = new TextExpr(CompareExpr.textForFuncName(compareFuncName));
        compare_text.color = 'black';
        super([b1, compare_text, b2]);
        this.funcName = compareFuncName;
        this.color = "HotPink";
    }
    get constructorArgs() { return [this.holes[0].clone(), this.holes[2].clone(), this.funcName]; }
    get leftExpr() { return this.holes[0]; }
    get rightExpr() { return this.holes[2]; }
    onmouseclick(pos) {
        console.log('Expressions are equal: ', this.compare());
        this.performReduction();
    }
    reduce() {
        var cmp = this.compare();
        if (cmp === true)       return new TrueExpr();
        else if (cmp === false) return new FalseExpr();
        else                    return this;
    }
    compare() {
        if (this.funcName === '==') {
            var lval = this.leftExpr.value();
            var rval = this.rightExpr.value();
            console.log('leftexpr', this.leftExpr.constructor.name, lval);
            console.log('rightexpr', this.rightExpr.constructor.name, rval);
            if (lval === undefined || rval === undefined) return undefined;
            return lval === rval;
        } else if (this.funcName === '!=') {
            return this.leftExpr.value() !== this.rightExpr.value();
        } else {
            console.warn('Compare function "' + this.funcName + '" not implemented.');
            return false;
        }
    }

    toString() {
        return '(' + this.funcName + ' ' + this.leftExpr.toString() + ' ' + this.rightExpr.toString() + ')';
    }
}

class NumberExpr extends Expression {
    constructor(num) {
        super([ new DiceNumber(num) ]);
        this.number = num;
        this.color = 'Ivory';
        this.highlightColor = 'OrangeRed';
    }
    get constructorArgs() { return [this.number]; }
    value() {
        return this.number;
    }
    toString() {
        return this.number.toString();
    }
}

// Draws the circles for a dice number inside its boundary.
class DiceNumber extends Rect {
    static drawPositionsFor(num) {
        let L = 0.15;
        let T = L;
        let R = 1.0 - L;
        let B = R;
        let M = 0.5;
        let map = {
            0: [],
            1: [ { x: M, y: M} ],
            2: [ { x: L, y: T }, { x: R, y: B } ],
            3: [ { x: R, y: T}, { x: M, y: M}, { x: L, y: B } ],
            4: [ { x: L, y: T}, { x: R, y: T}, { x: R, y: B }, { x: L, y: B } ],
            5: [ { x: L, y: T}, { x: R, y: T}, { x: R, y: B }, { x: L, y: B }, { x: M, y: M } ],
            6: [ { x: L, y: T}, { x: R, y: T}, { x: R, y: M }, { x: R, y: B }, { x: L, y: B }, { x: L, y: M } ]
        };
        if (num in map) return map[num];
        else {
            console.error('Dice pos array does not exist for number ' + num + '.');
            return [];
        }
    }
    constructor(num, radius=6) {
        super(0, 0, 44, 44);
        this.number = num;
        this.circlePos = DiceNumber.drawPositionsFor(num);
        this.radius = radius;
        this.color = 'black';
    }
    get constructorArgs() {
        return [ this.number, this.radius ];
    }
    hits(pos, options) { return false; }
    drawInternal(pos, boundingSize) {

        //this.ctx.fillStyle = 'red';
        //this.ctx.fillRect(pos.x, pos.y, boundingSize.w, boundingSize.h);

        if (this.circlePos && this.circlePos.length > 0) {

            let ctx = this.ctx;
            let rad = this.radius * boundingSize.w / this.size.w;
            let fill = this.color;
            let stroke = this.stroke;
            this.circlePos.forEach((relpos) => {
                let drawpos = { x: pos.x + boundingSize.w * relpos.x - rad, y: pos.y + boundingSize.h * relpos.y - rad };
                drawCircle(ctx, drawpos.x, drawpos.y, rad, fill, stroke);
            });

        }
    }
}

// Optional?
// Wrapper class to make arbitrary nodes into draggable expressions.
class VarExpr extends Expression {
    constructor(graphic_node) {
        super([graphic_node]);
        this.color = 'gold';
    }

    get color() { return super.color; }
    set color(clr) {
        this.holes[0].color = clr;
    }
    get delegateToInner() {
        return this.ignoreEvents || (!this.parent) || !(this.parent instanceof Expression);
    }
    get graphicNode() { return this.holes[0]; }

    //get size() { return this.holes[0].size; }
    hits(pos, options) {
        if(this.ignoreEvents) return null;
        if(this.holes[0].hits(pos, options)) return this;
        else return null;
    }
    onmouseenter(pos) {
        if (this.delegateToInner) this.holes[0].onmouseenter(pos);
        else super.onmouseenter(pos);
    }
    onmouseleave(pos) {
        if (!this.delegateToInner) super.onmouseleave(pos);
        this.holes[0].onmouseleave(pos);
    }
    drawInternal(pos, boundingSize) {
        if (!this.delegateToInner) {
            this._color = '#777';
            super.drawInternal(pos, boundingSize);
        }
    }
    value() { return this.holes[0].value(); }
}
class StarExpr extends VarExpr {
    constructor(x, y, rad, pts=5) {
        super(new Star(x, y, rad, pts));
    }
    toString() { return 'star'; }
}
class CircleExpr extends VarExpr {
    constructor(x, y, rad) {
        super(new Circle(x, y, rad));
    }
    toString() { return 'circle'; }
}
class PipeExpr extends VarExpr {
    constructor(x, y, w, h) {
        super(new Pipe(x, y, w, h-12));
    }
    toString() { return 'pipe'; }
}
class TriangleExpr extends VarExpr {
    constructor(x, y, w, h) {
        super(new Triangle(x, y, w, h));
    }
    toString() { return 'triangle'; }
}
class RectExpr extends VarExpr {
    constructor(x, y, w, h) {
        super(new Rect(x, y, w, h));
    }
    toString() { return 'diamond'; }
}
class ImageExpr extends VarExpr {
    constructor(x, y, w, h, resource_key) {
        super(new ImageRect(x, y, w, h, resource_key));
        this._image = resource_key;
    }
    get image() { return this._image; }
    set image(img) {
        this._image = img;
        this.graphicNode.image = img;
    }
    toString() { return this._image; }
}

/** Collections */
class CountExpr extends Expression {
    constructor(collectionExpr) {
        if (typeof collectionExpr === 'undefined') {
            collectionExpr = new MissingExpression();
            collectionExpr.color = 'lightgray';
        }
        let txt = new TextExpr('count');
        super([txt, collectionExpr]);
        this.color = 'DarkTurquoise';
        txt.color = 'white';
    }
    onmouseclick() {
        this.performReduction();
    }
    reduce() {
        console.log(this.holes[1]);
        if (this.holes[1] instanceof MissingExpression) return this;
        else if (this.holes[1] instanceof BagExpr)      return [new NumberExpr(this.holes[1].items.length), this.holes[1]];
        else                                            return this;
    }
}
class BagExpr extends VarExpr {
    constructor(x, y, w, h, holding=[]) {
        //super(new Bag(x, y, w, h));
        let radius = (w + h) / 4.0;
        super(new Circle(x, y, radius));
        this._items = holding;
        this.bigScale = 5;
        this.graphicNode.color = 'black';
        this.graphicNode.anchor = { x:0.5, y:0.5 };
        this.graphicNode.clipChildren = true;
        this.graphicNode.clipBackground = 'bag-background';
        this.anchor = { x:0.5, y:0.5 };
    }
    get items() { return this._items.slice(); }
    set items(items) {
        this._items = [];
        items.forEach((item) => {
            this.addItem(item);
        });
    }
    get delegateToInner() { return true; }
    //get size() {
    //    return { w:50, h:50 };
    //}

    // Adds an item to the bag.
    addItem(item) {
        let scale = 1.0/this.bigScale;
        let center = this.graphicNode.size.w / 2.0;
        let x = (item.pos.x - this.pos.x) / (1.0/scale) + center + item.size.w / 2.0 * scale;
        let y = (item.pos.y - this.pos.y) / (1.0/scale) + center + item.size.h / 2.0 * scale;
        console.log(x, y);
        item.pos = { x:x, y:y };
        item.anchor = { x:0.5, y:0.5 };
        item.scale = { x:scale, y:scale };
        item.onmouseleave();
        this._items.push(item);
        this.graphicNode.addChild(item);

        Resource.play('pop');
        Resource.play('bag-addItem');
    }

    // Spills the entire bag onto the play field.
    spill() {
        if (!this.stage) {
            console.error('@ BagExpr.spill: Bag is not attached to a Stage.');
            return;
        } else if (this.parent) {
            console.error('@ BagExpr.spill: Cannot spill a bag while it\'s inside of another expression.');
            return;
        }

        let stage = this.stage;
        let items = this.items;
        let pos = this.pos;

        // GAME DESIGN CHOICE:
        // Remove the bag from the stage.
        // stage.remove(this);

        // Add back all of this bags' items to the stage.
        items.forEach((item) => {
            let theta = Math.random() * Math.PI * 2;
            let rad = this.size.w * 1.5;
            let targetPos = addPos(pos, { x:rad*Math.cos(theta), y:rad*Math.sin(theta) } );
            item.pos = pos;
            Animate.tween(item, { 'pos':targetPos }, 100, (elapsed) => Math.pow(elapsed, 0.5));
            //item.pos = addPos(pos, { x:rad*Math.cos(theta), y:rad*Math.sin(theta) });
            item.parent = null;
            item.scale = { x:1, y:1 };
            stage.add(item);
        });

        // Set the items in the bag back to nothing.
        this.items = [];
        this.graphicNode.children = [];

        // Play spill sfx
        Resource.play('bag-spill');
    }

    reduce() {
        return this; // collections do not reduce!
    }
    value() {
        return this.items; // Arguably should be toString of each expression, but then comparison must be setCompare.
    }

    onmouseclick(pos) {
        this.spill();
    }

    ondropenter(node, pos) {

        if (this._tween) this._tween.cancel();

        this._beforeScale = this.graphicNode.scale;
        let targetScale = { x:this.bigScale, y:this.bigScale };
        this._tween = Animate.tween(this.graphicNode, { 'scale': targetScale }, 600, (elapsed) => Math.pow(elapsed, 0.25) );
        this.onmouseenter(pos);

        //if (this.stage) this.stage.draw();
    }
    ondropexit(node, pos) {

        this._tween.cancel();
        this._tween = Animate.tween(this.graphicNode, { 'scale': this._beforeScale }, 100, (elapsed) => Math.pow(elapsed, 0.25) );
        this.onmouseleave(pos);
    }
    ondropped(node, pos) {
        this.ondropexit(node, pos);

        if (!(node instanceof Expression)) {
            console.error('@ BagExpr.ondropped: Dropped node is not an Expression.', node);
            return;
        } else if (!node.stage) {
            console.error('@ BagExpr.ondropped: Dropped node is not attached to a Stage.', node);
            return;
        } else if (node.parent) {
            console.error('@ BagExpr.ondropped: Dropped node has a parent expression.', node);
            return;
        }

        // Remove node from the stage:
        let stage = node.stage;
        stage.remove(node);

        // Dump clone of node into the bag:
        let n = node.clone();
        n.pos.x = 100;//(n.absolutePos.x - this.graphicNode.absolutePos.x + this.graphicNode.absoluteSize.w / 2.0) / this.graphicNode.absoluteSize.w;
        this.addItem(n);
    }
}


// A while loop.
/* OLD -- class WhileLoop extends IfStatement {
    reduce() {
        if (!this.cond || !this.branch) return this; // irreducible
        else if (this.cond.value()) {
            this.branch.execute();
            return this; // step the branch, then return the same loop (irreducible)
        }
        else return this.emptyExpr;
    }
}

// A boolean expression. Can && or || or !.
class BooleanExpr extends Expression {
    constructor(b1, b2) {
        super(b1 || b2 ? [b1, b2] : [new TrueExpr(), new TrueExpr()]);
        this.OPTYPE = { AND:0, OR:1, NOT:2 };
        this.op = this.OPTYPE.AND;
    }

    // Change these when you subclass.
    get trueExpr() { return new TrueExpr(); }
    get falseExpr() { return new FalseExpr(); }

    // Reduces to TrueExpr or FalseExpr
    reduce() {
        var v = this.value();
        if (v) return this.trueExpr;
        else   return this.falseExpr;
    }

    value() {
        switch (this.op) {
            case this.OPTYPE.AND:
                return b1.value() && b2.value();
            case this.OPTYPE.OR:
                return b1.value() || b2.value();
            case this.OPTYPE.NOT:
                return !b1.value(); }
        console.error('Invalid optype.');
        return false;
    }
}*/
